<?php

// Config split.
$config['config_split.config_split.preview']['status'] = TRUE;

// Environment indicator.
$config['environment_indicator.indicator']['name'] = 'Preview';
$config['environment_indicator.indicator']['bg_color'] = '#B22222';
$config['environment_indicator.indicator']['fg_color'] = '#FFFFFF';