<?php

// Config split.
$config['config_split.config_split.develop']['status'] = TRUE;

// Environment indicator.
$config['environment_indicator.indicator']['name'] = 'Develop';
$config['environment_indicator.indicator']['bg_color'] = '#23812D';
$config['environment_indicator.indicator']['fg_color'] = '#FFFFFF';