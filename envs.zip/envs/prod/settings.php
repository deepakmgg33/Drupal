<?php

// Config split.
$config['config_split.config_split.production']['status'] = TRUE;

// Environment indicator.
$config['environment_indicator.indicator']['name'] = 'Production';
$config['environment_indicator.indicator']['bg_color'] = '#B22222';
$config['environment_indicator.indicator']['fg_color'] = '#FFFFFF';