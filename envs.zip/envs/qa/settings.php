<?php

// Config split.
$config['config_split.config_split.qa']['status'] = TRUE;

// Environment indicator.
$config['environment_indicator.indicator']['name'] = 'QA';
$config['environment_indicator.indicator']['bg_color'] = '#23812D';
$config['environment_indicator.indicator']['fg_color'] = '#FFFFFF';