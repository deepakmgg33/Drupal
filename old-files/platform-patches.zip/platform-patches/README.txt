/patches/core/drupal_core-percona_compliance-2856362-6-8.4.x.patch - Fix bug with Percona XtraDB Cluster
/patches/core/2429321-cache-factory-service-check-38.patch - Fix bug with settings cache default if it doesn't exist
/patches/core/core-2955317-fix_json_issue.patch - Use json format if content-type is json

/platform-patches/modules/draggableviews/draggableviews_save_args-8.x.10.patch - Save view args to the database
/platform-patches/modules/multiversion/multiversion-default_revision.patch - Set default revision
/platform-patches/modules/multiversion/multiversion_fixed_calling_method_null-8.x.patch - Fix calling method of null
/platform-patches/modules/openid_connect/openid_connect-username-2855-D8.patch - Set username as email
/platform-patches/modules/openid_connect/openid_fix.patch - Set user email to userinfo
/platform-patches/modules/workspace/bug-with-page_variant.patch - Fix bug with page_variant for admin
/platform-patches/modules/redis/redis_session_manager-8.x.patch - Create submodule to store PHP sessions in Redis
https://www.drupal.org/files/issues/redis-flood_unblock_external_flood-2928007-2.patch - Flood: Compatibility with Flood unblock
https://www.drupal.org/files/issues/flood_unblock-support_external-2928007-8.patch - Support external Flood